from socket import *
from time import *

time_out=1
clientSocket = socket(AF_INET, SOCK_DGRAM)
connet_to = ('',12000)
clientSocket.settimeout(time_out)
# print("----------------------------------------------------------------")
# print("client connection established")
# print("----------------------------------------------------------------")
try:
    for i in range(10):
        rtt = 0
        message = "Ping " + str(i+1) + " "
        t0 = time()
        message = message + ctime(t0)
        try:
            send = clientSocket.sendto(message.encode(), connet_to)
            # print("----------------------------------------------------------------")            
            # print(message + " Send to server")
            # print("----------------------------------------------------------------")    
            data, server = clientSocket.recvfrom(1024)
            tt = time()
            rtt = tt - t0
            print(data.decode() + f" RTT : {rtt:.6f}")
        except:
            # print("----------------------------------------------------------------")    
            print("Request timed out " + str(i+1))
            # print("----------------------------------------------------------------")    

finally:
    clientSocket.close()
    # print("----------------------------------------------------------------") 
    # print("Socket closed!!")
    # print("----------------------------------------------------------------") 
