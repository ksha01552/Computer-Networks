from socket import *
import ssl
from base64 import b64encode

mailserver = ("smtp.gmail.com", 587)

clientSocket = socket(AF_INET, SOCK_STREAM)
clientSocket.connect(mailserver)
recv = clientSocket.recv(1024).decode()
print(recv)
if recv[:3] != "220":
    print("220 Reply not received from server.")

# Send HELO command and print server response. 
heloCommand = "HELO Alice\r\n"
clientSocket.send(heloCommand.encode())
recv = clientSocket.recv(1024).decode()
print(recv)
if recv[:3] != "250":
    print("250 Reply not received from server.")

# Send request for TLS connection to mail server using socket
cmd = "STARTTLS\r\n"
clientSocket.send(cmd.encode())
recv = clientSocket.recv(1024).decode()
print(recv)
clientSocket = ssl.wrap_socket(clientSocket)

# Authentication details
userEmail = "smtplab23@gmail.com"
userPassword = "lmvgusmmhxkmzoti"

# email = (base64.b64encode("smtplab23@gmail.com".encode()) + ("\r\n").encode())
email = (b64encode(userEmail.encode()) + ("\r\n").encode())
password = (b64encode(userPassword.encode()) + ("\r\n").encode())

clientSocket.send("AUTH LOGIN\r\n".encode())
recv = clientSocket.recv(1024).decode()
print(recv)
clientSocket.send(email)
recv = clientSocket.recv(1024).decode()
print(recv)
clientSocket.send(password)
recv = clientSocket.recv(1024).decode()
print(recv)

# Send MAIL FROM command and print server response.
mailfrom = "MAIL FROM: <"+userEmail+">\r\n"
clientSocket.send(mailfrom.encode())
recv = clientSocket.recv(1024).decode()
if recv[:3] != "250":
    print ("250 Reply not received from server.")


# Send RCPT TO command and print server response.
recvid = input("Enter destination email address: ")
print("\n")
recvmsg = "RCPT TO: <"+recvid+">\r\n"
clientSocket.send(recvmsg.encode())
recv = clientSocket.recv(1024).decode()
print(recv)
if recv[:3] != "250":
    print ("250 Reply not received from server.")

# Send DATA command and print server response.
clientSocket.send("DATA\r\n".encode())
recv = clientSocket.recv(1024).decode()
print(recv)
if recv[:3] != "354":
    print ("354 Reply not received from server.")

# Send message data.
subject = input("Enter subject of the email: ")
clientSocket.send(("Subject: "+subject+" \r\n").encode())
clientSocket.send(("To: "+recvid+" \r\n").encode())
msg = "\r\n "
inp = input("Enter body of the email: ")
msg = msg + inp
clientSocket.send(msg.encode())

# Message ends with a single period.
endmsg = "\r\n.\r\n"
clientSocket.send(endmsg.encode())
recv = clientSocket.recv(1024).decode()
print(recv)
if recv[:3] != "250":
    print("250 Reply not received from server.")

# Send QUIT command and get server response.
clientSocket.send("QUIT\r\n".encode())
recv = clientSocket.recv(1024).decode()
print(recv)
if recv[:3] != "221":
    print("221 Reply not received from server.")

clientSocket.close()
print("Connection Closed!!")