from socket import *
import random
import time

def randomnum():
    return random.randint(1, 100)

port = 7906
server_socket = socket(AF_INET, SOCK_STREAM)
server_socket.bind(('', port))
server_socket.listen(5)
server_name = "MY_SERVER"
print("Server is listening")
connection, c_address = server_socket.accept()
while True:
    try:
        data = connection.recv(1024)
        data = data.decode()
        if not data:
            break
        print("Received form client :", data)
        client_name, client_number = data.split(" ")
        client_number = int(client_number)

        if client_number > 100 or client_number < 1:
            s_close = "Server closed"
            connection.send(s_close.encode())
            print("Server closed")
            break

        print("Client name: " + str(client_name))
        print("Server name: " + server_name)

        n = randomnum()
        s = n + client_number
        print("Client Number: " + str(client_number))
        print("Server Number: " + str(n))
        print("Sum = " + str(s))

        message = server_name + " " + str(n)

        time.sleep(1)
        connection.send(message.encode())
        print("Sending to the client", message)
    except Exception as e:
        print(e)

connection.close()
