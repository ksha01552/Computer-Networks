import socket

hostname = socket.gethostname()
print("Hostname:", hostname)
print(type(hostname))