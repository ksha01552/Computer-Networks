import socket
import random
import time

def randomnum():
    return random.randint(1, 100)

# server_address = ('localhost', 7905)
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((socket.gethostbyname(socket.gethostname()), 7906))
hostname = socket.gethostname()
while True:
    try:
        n = str(randomnum())
        message = str(hostname) + " " + str(n)
        print("Sending to Server:", message)
        client_socket.send(message.encode())
        time.sleep(1)
        data = client_socket.recv(1024)
        if data == "Server closed":
            print("Server closed connection")
            break
        print("Received form Server:", data.decode())

    except Exception as e:
        print(e)

client_socket.close()
